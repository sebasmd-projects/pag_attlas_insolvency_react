18/02/2025 - Home page initial meta data

18/02/2025 - change corporative colors

18/02/2025 - Home page Attlas
