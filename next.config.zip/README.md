# React | Next | ATTLAS Conciliación

## Getting Started - Dev

```bash
npm i
npm run dev
```

## Prod

```bash
git pull
npm i
npm run build
```

## Repository

```bash
https://github.com/sebasmd-projects/pag_attlas_insolvency_react.git
```

## React tools

```bash
react-devtools
```
