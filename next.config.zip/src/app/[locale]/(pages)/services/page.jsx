
export default function ServicesPage() {
    return (
        <div>
            <h1>ServicesPage</h1>
        </div>
    );
}