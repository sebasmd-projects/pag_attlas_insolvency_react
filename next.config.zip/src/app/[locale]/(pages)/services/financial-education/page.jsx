
export default function FinancialEducationPage() {
    return (
        <div>
            <h1>FinancialEducationPage</h1>
        </div>
    );
}