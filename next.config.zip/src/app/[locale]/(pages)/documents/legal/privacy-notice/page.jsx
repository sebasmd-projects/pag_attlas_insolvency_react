
export default function PrivacyNoticePage() {
  return (
    <div>
      <h1>Aviso de Privacidad</h1>
    </div>
  );
}