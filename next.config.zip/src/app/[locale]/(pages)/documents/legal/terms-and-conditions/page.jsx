
export default function TermsAndConditionsPage() {
    return (
        <div>
            <h1>Términos y Condiciones</h1>
        </div>
    );
}