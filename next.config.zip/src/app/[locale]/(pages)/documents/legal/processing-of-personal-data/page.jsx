
export default function ProcessingOfPersonalDataPage() {
    return (
        <div>
            <h1>Tratamiento de datos personales</h1>
        </div>
    );
}