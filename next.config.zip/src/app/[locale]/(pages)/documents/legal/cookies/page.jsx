
export default function CookiesPage() {
    return (
        <div>
            <h1>Cookies</h1>
        </div>
    );
}