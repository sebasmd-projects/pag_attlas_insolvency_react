
export default function PoliciesForTheTreatmentOfInformationPage() {
    return (
        <div>
            <h1>Políticas para el tratamiento de la información</h1>
        </div>
    );
}