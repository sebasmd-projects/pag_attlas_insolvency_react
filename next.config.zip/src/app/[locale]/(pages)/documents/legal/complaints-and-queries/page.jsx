
export default function ComplaintsAndQueriesPage() {
    return (
        <div>
            <h1>Reclamos y Consultas</h1>
        </div>
    );
}