
export default function FreeAdvicePage() {
    return (
        <div>
            <h1>FreeAdvicePage</h1>
        </div>
    );
}