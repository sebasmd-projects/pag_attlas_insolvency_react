
export default function CulturePage() {
    return (
        <div>
            <h1>CulturePage</h1>
        </div>
    );
}