
export default function HistoryPage() {
    return (
        <div>
            <h1>HistoryPage</h1>
        </div>
    );
}