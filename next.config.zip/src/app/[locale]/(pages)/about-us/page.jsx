
export default function AboutUsPage() {
    return (
        <div>
            <h1>AboutUsPage</h1>
        </div>
    );
}