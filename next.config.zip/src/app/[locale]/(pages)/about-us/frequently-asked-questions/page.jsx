
export default function FAQPage() {
    return (
        <div>
            <h1>Frequently Asked Questions</h1>
        </div>
    );
}