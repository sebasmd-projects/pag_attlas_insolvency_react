
export default function ForgotPasswordPage() {
  return (
    <div>
      <h1>ForgotPasswordPage</h1>
    </div>
  );
}